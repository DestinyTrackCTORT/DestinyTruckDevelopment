import pygame,sys #sys是python的标准库，提供Python运行时环境变量的操控
#import DTshell

import time
import error
pygame.init()  #内部各功能模块进行初始化创建及变量设置，默认调用
#DTshell.shell()
#sh = input(">>>(开始请回车)")
#if sh == "shell":
#    DTshell.shell()
x = 1200
y = 600
size = width,height = x,y  #设置游戏窗口大小，分别是宽度和高度
screen = pygame.display.set_mode(size)  #初始化显示窗口
pygame.display.set_caption("DestinyTruck (comeCTORT)")  #设置显示窗口的标题内容，是一个字符串类型
company_img = pygame.image.load("CTORT.png").convert()  # 背景图片
screen.blit(company_img, (0, 0))
x = 1
while True:  #无限循环，直到Python运行时退出结束
    if x == 2:
        time.sleep(3)
        blackground_img = pygame.image.load("destinytruck.png").convert()  # 背景图片
        screen.blit(blackground_img, (0, 0))
    if x == 3:
        time.sleep(3)
        error.error()
        sys.exit()
    for event in pygame.event.get():  #从Pygame的事件队列中取出事件，并从队列中删除该事件
        if event.type == pygame.QUIT:  #获得事件类型，并逐类响应
            sys.exit()   #用于退出结束游戏并退出   
    x += 1       
    pygame.display.update()  #对显示窗口进行更新，默认窗口全部重绘
