from tkinter import *
import tkinter as tk
import tkinter.messagebox

#top = Tk()  #创建窗口
#top.title("DT ERROR")  #定义窗口名称
#top.geometry('250x125')  #设置主窗口大小，注意中间对的符号是小写字母x
#创建文本标签Label,top是第一个参数为父窗口，text是标签内容
#设置位置参数，使用place方法可将控件放在指定位置，
#place()方法中窗口显示区左上角是(0,0),x是向右递增，y是向下递增
#Label(top,text = ":(  error连接错误！！！").place(x = 65,y = 40)  
#创建按钮，text是功能按钮的名称

def error():
    tkinter.messagebox.showerror(title='Error', message='Sorry,we have problem!!!')
    tkinter.messagebox.showinfo(title='Destiny Truck日志', message='Destiny Truck日志：\n无法连接至服务器！！！\n服务器暂停开放，闭服维护中...')
#Button(top,text = "退出").place(x = 100,y = 75)
#tk.Button(top, text='退出',  command=error).pack()
#error()

    
#top.mainloop()

