def resolution():
    x = int(input("请输入x:"))
    y = int(input("请输入y:"))
    size = width,height = x,y
x = 0
def shell(x):
        if x == 0:
            print("DTshell v1.0.0\n输入help查看指令\n")
            x += 1
        sh = input("请输入调试指令>>>")
        if sh == "help":
            print("1.屏幕分辨率:  resolution")
        if sh == "resolution":
            resolution()
        